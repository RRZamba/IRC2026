<?php
	//Conectando com o server
	$con = mysqli_connect('localhost',
				   		  'root',
				   		  '',
				          'produtos');

	//Tratando o retorno
	if(!$con)
	{
		die("Erro ao conectar!!! MORRA! OTÁRIO!"); 
	}
?>