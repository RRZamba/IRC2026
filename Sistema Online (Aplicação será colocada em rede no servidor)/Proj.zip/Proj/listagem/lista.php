<?php
	// 1) Incluindo o conexao.php
	include '../conexao/conexao.php';

	// 2) Variável para guardar a query
	$query = 'SELECT * FROM produto';

	// 3) Executando a query
	$result = mysqli_query($con,$query);

?>

<html>
<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>

	<title>Lista Show</title>
</head>
<body>
	<div class="container mt-4">
		<!-- !!!Cabeçalho bonitinho!!! --> 
		<div class="mb-4 bg-light rounded-3 shadow-sm">
			<div class="container-fluid py-3">
				<h1>Produtos Cadastrados</h1>
				<p class="col-md-8">Produtos Fofos</p>
			</div>
		</div>

		<!-- Menu de navegação bonitinho -->
		<ul class="nav nav-tabs mb-3">
			<li class="nav-item">
				<a href="#">
					Cadastrar Produto
				</a>
			</li>

			<li class="nav-item">
				<a href="#">
					Listar Produto
				</a>
			</li>

			<li class="nav-item">
				<a href="#">
					Usuários
				</a>
			</li>
		</ul>


		<!-- Tabela bonitinha -->
		<table class="table table-striped">
			<tr>
				<th>Nome</th>
				<th>Descrição</th>
				<th>Área</th>
				<th>Preço</th>
				<th>Moeda</th>
				<th>País</th>
				<th>Editar</th>
				<th>Visualizar</th>
			</tr>

			<?php
				// 4) Percorrendo os resultados
				while($linha = mysqli_fetch_array($result)) 
				{	
					// 5) Mostrando os dados
					echo "
					   <tr>		
					    	<td>".$linha['nome']."</td>
							<td>".$linha['descricao']."</td>
							<td>".$linha['area']."</td>
							<td>".$linha['preco']."</td>
							<td>".$linha['moeda']."</td>
							<td>".$linha['pais']."</td>
							<td> Editar </td>
							<td> Visualizar </td>
						</tr>	

						";
				}

			?>



		</table>
	</div>
</body>
</html>